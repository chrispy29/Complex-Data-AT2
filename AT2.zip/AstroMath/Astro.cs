﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
/*Christopher Prickett - 30053736, 27/03/2023
 * Complex Data Structures, Assessment 2
 * Dynamic linked library with four methods to perform the calculation of star velocity, star distance, temperature in kelvin, and the event horizon
 * of a black hole.
 */

namespace AstroMath
{
    public class Astro
    {
        /// <summary>
        /// Method to calculate the velocity of a star.
        /// </summary>
        /// <param name="observedWavelength"> the observed wavelength input by user.</param>
        /// <param name="restWavelength"> the rest wavelength input by user.</param>
        /// <returns>the velocity in metres per second</returns>
        public double StarVelocity(double observedWavelength, double restWavelength)
        {
            if (observedWavelength - restWavelength != 0)
            {
                return (2.99792458 * Math.Pow(10, 8)) * ((observedWavelength - restWavelength) / restWavelength);
            }
            else
            {
                return -1;
            }
        }
        /// <summary>
        /// Method to calculate the distance of a star.
        /// </summary>
        /// <param name="Arceseconds">The parallax angle in arcseconds input by user.</param>
        /// <returns>The star distance in parsecs.</returns>
        public double StarDistance(double Arceseconds)
        {
            if (Arceseconds != 0)
            {
                return 1 / Arceseconds;
            }
            else
            {
                return -1;
            }
        }
        /// <summary>
        /// Method to calculate the temperature in Kelvin.
        /// </summary>
        /// <param name="degreesCelsius">The temperature in Celsius imput by user.</param>
        /// <returns>The temperature in Kelvin.</returns>
        public double DegreesKelvin(double degreesCelsius)
        {
            if (degreesCelsius > -273 && degreesCelsius < 10000)
            {
                return degreesCelsius + 273;
            }
            else
            {
                return -1;
            }
        }
        /// <summary>
        /// Method to calculate the event horizon of a black hole.
        /// </summary>
        /// <param name="blackHoleMass">The mass of the black hole in kilograms input by user.</param>
        /// <returns> The Schwarzdchild radius in metres.</returns>
        public double EventHorizon(double blackHoleMass)
        {
            if (blackHoleMass != 0)
            {
                return ((2 * (6.674 * Math.Pow(10, -11))) * blackHoleMass) / (Math.Pow(299792458, 2));
            }
            else
            { 
                return -1; 
            }           
        }
    }
}
