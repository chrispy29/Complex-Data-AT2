﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;
/* Christopher Prickett - 30053736, 27/03/2023
 * Complex Data Structures, Assessment 2
 * A client test program to test the server connection and the calculations based on user input.
 */

namespace ClientTest
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Connecting to the server to access dll methods
            string address = "net.pipe://localhost/astronumbers";
            NetNamedPipeBinding binding = new NetNamedPipeBinding(NetNamedPipeSecurityMode.None);
            EndpointAddress ep = new EndpointAddress(address);
            IAstroContract channel = ChannelFactory<IAstroContract>.CreateChannel(binding, ep);

            Console.WriteLine("Connected to server");
            // Testing star velocity
            double value1 = 1;
            double value2 = 1;
            Console.WriteLine("Enter observed wavelength: ");
            value1 = double.Parse(Console.ReadLine());
            Console.WriteLine("Enter rest wavelength: ");
            value2 = double.Parse(Console.ReadLine());

            double velocity = channel.StarVelocity(value1, value2);
            Console.WriteLine("Star Velocity: " +  velocity);            
            // Testing star distance
            double value3 = 1;
            Console.WriteLine("Enter Arcseconds: ");
            value3 = double.Parse(Console.ReadLine());

            double distance = channel.StarDistance(value3);
            Console.WriteLine("Star Distance: " + distance);
            // Testing degrees in kelvin
            double value4 = 1;
            Console.WriteLine("Enter degrees in celsius: ");
            value4 = double.Parse(Console.ReadLine());

            double kelvin = channel.DegreesKelvin(value4);
            Console.WriteLine("Degrees in Kelvin: " + kelvin);
            // Testing Event Horizon
            double value5 = 1;
            Console.WriteLine("Enter blackhole mass: ");
            value5 = double.Parse(Console.ReadLine()) * Math.Pow(10, 36);

            double mass = channel.EventHorizon(value5);
            Console.WriteLine("Radius: " +  mass);
            // Closing the test environment
            Console.CancelKeyPress += new ConsoleCancelEventHandler(CancelKey);
            Console.WriteLine("Press <<Ctrl + C>> to exit.");           
            Console.ReadLine();
        }
        // Close method to end testing.
        static void CancelKey(object sender, ConsoleCancelEventArgs e)
        {
            Console.WriteLine("Calculations complete, program exiting.");
            Environment.Exit(0);
        }
    }
}
