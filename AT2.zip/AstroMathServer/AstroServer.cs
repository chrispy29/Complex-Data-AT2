﻿using AstroMath;
using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;

namespace AstroMathServer
{
    [ServiceBehavior(InstanceContextMode = InstanceContextMode.Single)]  
    internal class AstroServer : IAstroContract
    {
       /// <summary>
       /// Creating an instance of the dll workspace to implement the calculations.
       /// </summary>
        Astro astro = new Astro();
        public double StarVelocity(double observedWavelength, double restWavelength)
        {
            return astro.StarVelocity(observedWavelength, restWavelength);
        }
        public double StarDistance(double Arcseconds)
        {
            return astro.StarDistance(Arcseconds);
        }
        public double DegreesKelvin(double degreesCelsius)
        {
            return astro.DegreesKelvin(degreesCelsius);
        }
        public double EventHorizon(double blackHoleMass)
        {
            return astro.EventHorizon(blackHoleMass);
        }
    }
}
