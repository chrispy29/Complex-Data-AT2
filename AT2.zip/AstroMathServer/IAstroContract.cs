﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;
using AstroMath;

namespace AstroMathServer
{
    [ServiceContract]
    internal interface IAstroContract
    {
        /// <summary>
        /// Contracts to implement calculations from dll.
        /// </summary>
        /// <param name="a">Double that will hold user input for calculation.</param>
        /// <param name="b">Double that will hold user input for calculation.</param>
        /// <returns>The result of the calculations.</returns>
        [OperationContract]
        double StarVelocity(double a, double b);

        [OperationContract]
        double StarDistance(double a);

        [OperationContract]
        double DegreesKelvin(double a);

        [OperationContract]
        double EventHorizon(double a);
    }
}
