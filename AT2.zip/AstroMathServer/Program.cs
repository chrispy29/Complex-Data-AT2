﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;
/*Christopher Prickett - 30053736, 27/03/2023
 * Complex Data Structures, Assessment 2
 * A server program to connect a client program to perform calculations based on contents of DLL.
 */

namespace AstroMathServer
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Connecting to the server.
            string address = "net.pipe://localhost/astronumbers";
            
            ServiceHost Host = new ServiceHost(typeof(AstroServer));
            NetNamedPipeBinding binding = new NetNamedPipeBinding(NetNamedPipeSecurityMode.None);
            Host.AddServiceEndpoint(typeof(IAstroContract), binding, address);
            Host.Open();
            // Event handler to close server that calls close method.
            Console.CancelKeyPress += new ConsoleCancelEventHandler(CancelKey);
            Console.WriteLine("Malin Server is running. Press <<Ctrl + C>> to exit.");
            Console.ReadLine();
            Host.Close();
        }
        // Close method used to close server console.
        static void CancelKey(object sender, ConsoleCancelEventArgs e)
        {
            Console.WriteLine("Server exit has occured. Will now close.");
            Environment.Exit(0);
        }
    }
}
