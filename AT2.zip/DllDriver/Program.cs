﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AstroMath;
/* Christopher Prickett - 30053736, 27/03/2023
 * Complex Data Structures, Assessment 2
 * A program to test the DLL and that it performs all calculations correctly.
 */


namespace DllDriver
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Astro astro = new Astro();
            // Writing on the console results of the calculations based on hard coded input values.
            Console.WriteLine("Star Velocity: " + astro.StarVelocity(500.1, 500));
            Console.WriteLine("Star Distance: " + astro.StarDistance(0.547));
            Console.WriteLine("Temp in Kelvin: " + astro.DegreesKelvin(27));
            Console.WriteLine("Event Horizon: " + astro.EventHorizon(8.2 * Math.Pow(10, 36)));
            Console.ReadLine();
        }
    }
}
