﻿namespace MalinCalculations
{
    partial class FormMalinCalculations
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormMalinCalculations));
            this.LabelVelocity = new System.Windows.Forms.Label();
            this.LabelObserved = new System.Windows.Forms.Label();
            this.LabelRest = new System.Windows.Forms.Label();
            this.LabelDistance = new System.Windows.Forms.Label();
            this.LabelAngle = new System.Windows.Forms.Label();
            this.LabelKelvin = new System.Windows.Forms.Label();
            this.LabelCelsius = new System.Windows.Forms.Label();
            this.LabelHorizon = new System.Windows.Forms.Label();
            this.LabelMass = new System.Windows.Forms.Label();
            this.TextBoxObserve = new System.Windows.Forms.TextBox();
            this.TextBoxRest = new System.Windows.Forms.TextBox();
            this.TextBoxArcseconds = new System.Windows.Forms.TextBox();
            this.TextBoxCelsius = new System.Windows.Forms.TextBox();
            this.TextBoxMass = new System.Windows.Forms.TextBox();
            this.ButtonCalculate = new System.Windows.Forms.Button();
            this.ListViewCalculationResults = new System.Windows.Forms.ListView();
            this.columnVelocity = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnDistance = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnKelvin = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHorizon = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.StatusStripInfo = new System.Windows.Forms.StatusStrip();
            this.MenuStripOptions = new System.Windows.Forms.MenuStrip();
            this.MenuItemLanguage = new System.Windows.Forms.ToolStripMenuItem();
            this.MenuItemEnglish = new System.Windows.Forms.ToolStripMenuItem();
            this.MenuItemFrench = new System.Windows.Forms.ToolStripMenuItem();
            this.MenuItemGerman = new System.Windows.Forms.ToolStripMenuItem();
            this.MenuItemStyle = new System.Windows.Forms.ToolStripMenuItem();
            this.MenuItemColor = new System.Windows.Forms.ToolStripMenuItem();
            this.MenuItemForm = new System.Windows.Forms.ToolStripMenuItem();
            this.MenuItemDark = new System.Windows.Forms.ToolStripMenuItem();
            this.MenuItemLight = new System.Windows.Forms.ToolStripMenuItem();
            this.MenuItemDefault = new System.Windows.Forms.ToolStripMenuItem();
            this.LabelMultiplier = new System.Windows.Forms.Label();
            this.NumericMultiplier = new System.Windows.Forms.NumericUpDown();
            this.ButtonDarkLight = new System.Windows.Forms.Button();
            this.ButtonDefaultColor = new System.Windows.Forms.Button();
            this.ButtonGerman = new System.Windows.Forms.Button();
            this.ButtonFrench = new System.Windows.Forms.Button();
            this.ButtonEnglish = new System.Windows.Forms.Button();
            this.ToolTips = new System.Windows.Forms.ToolTip(this.components);
            this.MenuStripOptions.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.NumericMultiplier)).BeginInit();
            this.SuspendLayout();
            // 
            // LabelVelocity
            // 
            this.LabelVelocity.AutoSize = true;
            this.LabelVelocity.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LabelVelocity.Location = new System.Drawing.Point(12, 24);
            this.LabelVelocity.Name = "LabelVelocity";
            this.LabelVelocity.Size = new System.Drawing.Size(146, 25);
            this.LabelVelocity.TabIndex = 0;
            this.LabelVelocity.Text = "Star Velocity";
            // 
            // LabelObserved
            // 
            this.LabelObserved.AutoSize = true;
            this.LabelObserved.Location = new System.Drawing.Point(12, 61);
            this.LabelObserved.Name = "LabelObserved";
            this.LabelObserved.Size = new System.Drawing.Size(117, 13);
            this.LabelObserved.TabIndex = 1;
            this.LabelObserved.Text = "Observed Wavelength:";
            // 
            // LabelRest
            // 
            this.LabelRest.AutoSize = true;
            this.LabelRest.Location = new System.Drawing.Point(12, 118);
            this.LabelRest.Name = "LabelRest";
            this.LabelRest.Size = new System.Drawing.Size(93, 13);
            this.LabelRest.TabIndex = 2;
            this.LabelRest.Text = "Rest Wavelength:";
            // 
            // LabelDistance
            // 
            this.LabelDistance.AutoSize = true;
            this.LabelDistance.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LabelDistance.Location = new System.Drawing.Point(12, 175);
            this.LabelDistance.Name = "LabelDistance";
            this.LabelDistance.Size = new System.Drawing.Size(154, 25);
            this.LabelDistance.TabIndex = 3;
            this.LabelDistance.Text = "Star Distance";
            // 
            // LabelAngle
            // 
            this.LabelAngle.AutoSize = true;
            this.LabelAngle.Location = new System.Drawing.Point(12, 212);
            this.LabelAngle.Name = "LabelAngle";
            this.LabelAngle.Size = new System.Drawing.Size(96, 13);
            this.LabelAngle.TabIndex = 4;
            this.LabelAngle.Text = "Arcseconds Angle:";
            // 
            // LabelKelvin
            // 
            this.LabelKelvin.AutoSize = true;
            this.LabelKelvin.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LabelKelvin.Location = new System.Drawing.Point(12, 269);
            this.LabelKelvin.Name = "LabelKelvin";
            this.LabelKelvin.Size = new System.Drawing.Size(168, 25);
            this.LabelKelvin.TabIndex = 5;
            this.LabelKelvin.Text = "Temp in Kelvin";
            // 
            // LabelCelsius
            // 
            this.LabelCelsius.AutoSize = true;
            this.LabelCelsius.Location = new System.Drawing.Point(12, 306);
            this.LabelCelsius.Name = "LabelCelsius";
            this.LabelCelsius.Size = new System.Drawing.Size(84, 13);
            this.LabelCelsius.TabIndex = 6;
            this.LabelCelsius.Text = "Temp in Celsius:";
            // 
            // LabelHorizon
            // 
            this.LabelHorizon.AutoSize = true;
            this.LabelHorizon.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LabelHorizon.Location = new System.Drawing.Point(12, 363);
            this.LabelHorizon.Name = "LabelHorizon";
            this.LabelHorizon.Size = new System.Drawing.Size(160, 25);
            this.LabelHorizon.TabIndex = 7;
            this.LabelHorizon.Text = "Event Horizon";
            // 
            // LabelMass
            // 
            this.LabelMass.AutoSize = true;
            this.LabelMass.Location = new System.Drawing.Point(12, 400);
            this.LabelMass.Name = "LabelMass";
            this.LabelMass.Size = new System.Drawing.Size(90, 13);
            this.LabelMass.TabIndex = 8;
            this.LabelMass.Text = "Black Hole Mass:";
            // 
            // TextBoxObserve
            // 
            this.TextBoxObserve.Location = new System.Drawing.Point(12, 86);
            this.TextBoxObserve.Name = "TextBoxObserve";
            this.TextBoxObserve.Size = new System.Drawing.Size(100, 20);
            this.TextBoxObserve.TabIndex = 9;
            this.ToolTips.SetToolTip(this.TextBoxObserve, "Enter Observed Wavelength");
            // 
            // TextBoxRest
            // 
            this.TextBoxRest.Location = new System.Drawing.Point(12, 143);
            this.TextBoxRest.Name = "TextBoxRest";
            this.TextBoxRest.Size = new System.Drawing.Size(100, 20);
            this.TextBoxRest.TabIndex = 10;
            this.ToolTips.SetToolTip(this.TextBoxRest, "Enter Rest Wavelength");
            // 
            // TextBoxArcseconds
            // 
            this.TextBoxArcseconds.Location = new System.Drawing.Point(12, 237);
            this.TextBoxArcseconds.Name = "TextBoxArcseconds";
            this.TextBoxArcseconds.Size = new System.Drawing.Size(100, 20);
            this.TextBoxArcseconds.TabIndex = 11;
            this.ToolTips.SetToolTip(this.TextBoxArcseconds, "Enter Parallax Angle");
            // 
            // TextBoxCelsius
            // 
            this.TextBoxCelsius.Location = new System.Drawing.Point(12, 331);
            this.TextBoxCelsius.Name = "TextBoxCelsius";
            this.TextBoxCelsius.Size = new System.Drawing.Size(100, 20);
            this.TextBoxCelsius.TabIndex = 12;
            this.ToolTips.SetToolTip(this.TextBoxCelsius, "Enter Temperature in Celsius");
            // 
            // TextBoxMass
            // 
            this.TextBoxMass.Location = new System.Drawing.Point(12, 425);
            this.TextBoxMass.Name = "TextBoxMass";
            this.TextBoxMass.Size = new System.Drawing.Size(100, 20);
            this.TextBoxMass.TabIndex = 13;
            this.ToolTips.SetToolTip(this.TextBoxMass, "Enter Black Hole Mass (kg)");
            // 
            // ButtonCalculate
            // 
            this.ButtonCalculate.Location = new System.Drawing.Point(6, 489);
            this.ButtonCalculate.Name = "ButtonCalculate";
            this.ButtonCalculate.Size = new System.Drawing.Size(106, 57);
            this.ButtonCalculate.TabIndex = 15;
            this.ButtonCalculate.Text = "Calculate";
            this.ToolTips.SetToolTip(this.ButtonCalculate, "Calculate all information");
            this.ButtonCalculate.UseVisualStyleBackColor = true;
            this.ButtonCalculate.MouseClick += new System.Windows.Forms.MouseEventHandler(this.ButtonCalculate_MouseClick);
            // 
            // ListViewCalculationResults
            // 
            this.ListViewCalculationResults.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnVelocity,
            this.columnDistance,
            this.columnKelvin,
            this.columnHorizon});
            this.ListViewCalculationResults.GridLines = true;
            this.ListViewCalculationResults.HideSelection = false;
            this.ListViewCalculationResults.Location = new System.Drawing.Point(329, 27);
            this.ListViewCalculationResults.Name = "ListViewCalculationResults";
            this.ListViewCalculationResults.Size = new System.Drawing.Size(634, 519);
            this.ListViewCalculationResults.TabIndex = 18;
            this.ListViewCalculationResults.UseCompatibleStateImageBehavior = false;
            this.ListViewCalculationResults.View = System.Windows.Forms.View.Details;
            // 
            // columnVelocity
            // 
            this.columnVelocity.Text = "Star Velocity:";
            this.columnVelocity.Width = 157;
            // 
            // columnDistance
            // 
            this.columnDistance.Text = "Star Distance:";
            this.columnDistance.Width = 157;
            // 
            // columnKelvin
            // 
            this.columnKelvin.Text = "Temp Kelvin:";
            this.columnKelvin.Width = 157;
            // 
            // columnHorizon
            // 
            this.columnHorizon.Text = "Event Horizon:";
            this.columnHorizon.Width = 157;
            // 
            // StatusStripInfo
            // 
            this.StatusStripInfo.Location = new System.Drawing.Point(0, 623);
            this.StatusStripInfo.Name = "StatusStripInfo";
            this.StatusStripInfo.Size = new System.Drawing.Size(989, 22);
            this.StatusStripInfo.TabIndex = 19;
            this.StatusStripInfo.Text = "statusStrip1";
            // 
            // MenuStripOptions
            // 
            this.MenuStripOptions.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MenuItemLanguage,
            this.MenuItemStyle});
            this.MenuStripOptions.Location = new System.Drawing.Point(0, 0);
            this.MenuStripOptions.Name = "MenuStripOptions";
            this.MenuStripOptions.Size = new System.Drawing.Size(989, 24);
            this.MenuStripOptions.TabIndex = 23;
            this.MenuStripOptions.Text = "menuStrip1";
            // 
            // MenuItemLanguage
            // 
            this.MenuItemLanguage.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MenuItemEnglish,
            this.MenuItemFrench,
            this.MenuItemGerman});
            this.MenuItemLanguage.Name = "MenuItemLanguage";
            this.MenuItemLanguage.Size = new System.Drawing.Size(71, 20);
            this.MenuItemLanguage.Text = "Language";
            this.MenuItemLanguage.ToolTipText = "Changeable Languages";
            // 
            // MenuItemEnglish
            // 
            this.MenuItemEnglish.Image = global::MalinCalculations.Properties.Resources.flag_of_UK;
            this.MenuItemEnglish.Name = "MenuItemEnglish";
            this.MenuItemEnglish.Size = new System.Drawing.Size(116, 22);
            this.MenuItemEnglish.Text = "English";
            this.MenuItemEnglish.ToolTipText = "Change Language to English";
            this.MenuItemEnglish.Click += new System.EventHandler(this.MenuItemEnglish_Click);
            // 
            // MenuItemFrench
            // 
            this.MenuItemFrench.Image = global::MalinCalculations.Properties.Resources.flag_of_France;
            this.MenuItemFrench.Name = "MenuItemFrench";
            this.MenuItemFrench.Size = new System.Drawing.Size(116, 22);
            this.MenuItemFrench.Text = "French";
            this.MenuItemFrench.ToolTipText = "Change Language to French";
            this.MenuItemFrench.Click += new System.EventHandler(this.MenuItemFrench_Click);
            // 
            // MenuItemGerman
            // 
            this.MenuItemGerman.Image = global::MalinCalculations.Properties.Resources.flag_of_Germany;
            this.MenuItemGerman.Name = "MenuItemGerman";
            this.MenuItemGerman.Size = new System.Drawing.Size(116, 22);
            this.MenuItemGerman.Text = "German";
            this.MenuItemGerman.ToolTipText = "Change Language to German";
            this.MenuItemGerman.Click += new System.EventHandler(this.MenuItemGerman_Click);
            // 
            // MenuItemStyle
            // 
            this.MenuItemStyle.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MenuItemColor,
            this.MenuItemForm});
            this.MenuItemStyle.Name = "MenuItemStyle";
            this.MenuItemStyle.Size = new System.Drawing.Size(44, 20);
            this.MenuItemStyle.Text = "Style";
            // 
            // MenuItemColor
            // 
            this.MenuItemColor.Name = "MenuItemColor";
            this.MenuItemColor.Size = new System.Drawing.Size(103, 22);
            this.MenuItemColor.Text = "Color";
            this.MenuItemColor.ToolTipText = "Customise Color Change";
            this.MenuItemColor.Click += new System.EventHandler(this.MenuItemColor_Click);
            // 
            // MenuItemForm
            // 
            this.MenuItemForm.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MenuItemDark,
            this.MenuItemLight,
            this.MenuItemDefault});
            this.MenuItemForm.Name = "MenuItemForm";
            this.MenuItemForm.Size = new System.Drawing.Size(103, 22);
            this.MenuItemForm.Text = "Form";
            // 
            // MenuItemDark
            // 
            this.MenuItemDark.Name = "MenuItemDark";
            this.MenuItemDark.Size = new System.Drawing.Size(112, 22);
            this.MenuItemDark.Text = "Dark";
            this.MenuItemDark.ToolTipText = "Change to Dark Mode";
            this.MenuItemDark.Click += new System.EventHandler(this.MenuItemDark_Click);
            // 
            // MenuItemLight
            // 
            this.MenuItemLight.Name = "MenuItemLight";
            this.MenuItemLight.Size = new System.Drawing.Size(112, 22);
            this.MenuItemLight.Text = "Light";
            this.MenuItemLight.ToolTipText = "Change to Light Mode";
            this.MenuItemLight.Click += new System.EventHandler(this.MenuItemLight_Click);
            // 
            // MenuItemDefault
            // 
            this.MenuItemDefault.Name = "MenuItemDefault";
            this.MenuItemDefault.Size = new System.Drawing.Size(112, 22);
            this.MenuItemDefault.Text = "Default";
            this.MenuItemDefault.ToolTipText = "Change to Default Colors";
            this.MenuItemDefault.Click += new System.EventHandler(this.MenuItemDefault_Click);
            // 
            // LabelMultiplier
            // 
            this.LabelMultiplier.AutoSize = true;
            this.LabelMultiplier.Location = new System.Drawing.Point(118, 432);
            this.LabelMultiplier.Name = "LabelMultiplier";
            this.LabelMultiplier.Size = new System.Drawing.Size(24, 13);
            this.LabelMultiplier.TabIndex = 24;
            this.LabelMultiplier.Text = "x10";
            // 
            // NumericMultiplier
            // 
            this.NumericMultiplier.Location = new System.Drawing.Point(143, 415);
            this.NumericMultiplier.Name = "NumericMultiplier";
            this.NumericMultiplier.Size = new System.Drawing.Size(37, 20);
            this.NumericMultiplier.TabIndex = 14;
            this.ToolTips.SetToolTip(this.NumericMultiplier, "Input Multiplier");
            // 
            // ButtonDarkLight
            // 
            this.ButtonDarkLight.Location = new System.Drawing.Point(175, 518);
            this.ButtonDarkLight.Name = "ButtonDarkLight";
            this.ButtonDarkLight.Size = new System.Drawing.Size(148, 23);
            this.ButtonDarkLight.TabIndex = 26;
            this.ButtonDarkLight.Text = "Dark/Light Mode";
            this.ToolTips.SetToolTip(this.ButtonDarkLight, "Change to dark/light mode");
            this.ButtonDarkLight.UseVisualStyleBackColor = true;
            this.ButtonDarkLight.MouseClick += new System.Windows.Forms.MouseEventHandler(this.ButtonDarkLight_MouseClick);
            // 
            // ButtonDefaultColor
            // 
            this.ButtonDefaultColor.Location = new System.Drawing.Point(175, 489);
            this.ButtonDefaultColor.Name = "ButtonDefaultColor";
            this.ButtonDefaultColor.Size = new System.Drawing.Size(148, 23);
            this.ButtonDefaultColor.TabIndex = 27;
            this.ButtonDefaultColor.Text = "Default Color";
            this.ToolTips.SetToolTip(this.ButtonDefaultColor, "Change to default colors");
            this.ButtonDefaultColor.UseVisualStyleBackColor = true;
            this.ButtonDefaultColor.MouseClick += new System.Windows.Forms.MouseEventHandler(this.ButtonDefaultColor_MouseClick);
            // 
            // ButtonGerman
            // 
            this.ButtonGerman.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("ButtonGerman.BackgroundImage")));
            this.ButtonGerman.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ButtonGerman.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ButtonGerman.Location = new System.Drawing.Point(851, 562);
            this.ButtonGerman.Name = "ButtonGerman";
            this.ButtonGerman.Size = new System.Drawing.Size(109, 48);
            this.ButtonGerman.TabIndex = 22;
            this.ButtonGerman.Text = "German";
            this.ToolTips.SetToolTip(this.ButtonGerman, "Change Language to German");
            this.ButtonGerman.UseVisualStyleBackColor = true;
            this.ButtonGerman.MouseClick += new System.Windows.Forms.MouseEventHandler(this.ButtonGerman_MouseClick);
            // 
            // ButtonFrench
            // 
            this.ButtonFrench.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("ButtonFrench.BackgroundImage")));
            this.ButtonFrench.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ButtonFrench.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ButtonFrench.Location = new System.Drawing.Point(586, 562);
            this.ButtonFrench.Name = "ButtonFrench";
            this.ButtonFrench.Size = new System.Drawing.Size(109, 48);
            this.ButtonFrench.TabIndex = 21;
            this.ButtonFrench.Text = "French";
            this.ToolTips.SetToolTip(this.ButtonFrench, "Change Language to French");
            this.ButtonFrench.UseVisualStyleBackColor = true;
            this.ButtonFrench.MouseClick += new System.Windows.Forms.MouseEventHandler(this.ButtonFrench_MouseClick);
            // 
            // ButtonEnglish
            // 
            this.ButtonEnglish.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("ButtonEnglish.BackgroundImage")));
            this.ButtonEnglish.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ButtonEnglish.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ButtonEnglish.Location = new System.Drawing.Point(329, 562);
            this.ButtonEnglish.Name = "ButtonEnglish";
            this.ButtonEnglish.Size = new System.Drawing.Size(109, 48);
            this.ButtonEnglish.TabIndex = 20;
            this.ButtonEnglish.Text = "English";
            this.ToolTips.SetToolTip(this.ButtonEnglish, "Change Language to English");
            this.ButtonEnglish.UseVisualStyleBackColor = true;
            this.ButtonEnglish.MouseClick += new System.Windows.Forms.MouseEventHandler(this.ButtonEnglish_MouseClick);
            // 
            // FormMalinCalculations
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(989, 645);
            this.Controls.Add(this.ButtonDefaultColor);
            this.Controls.Add(this.ButtonDarkLight);
            this.Controls.Add(this.NumericMultiplier);
            this.Controls.Add(this.LabelMultiplier);
            this.Controls.Add(this.ButtonGerman);
            this.Controls.Add(this.ButtonFrench);
            this.Controls.Add(this.ButtonEnglish);
            this.Controls.Add(this.StatusStripInfo);
            this.Controls.Add(this.MenuStripOptions);
            this.Controls.Add(this.ListViewCalculationResults);
            this.Controls.Add(this.ButtonCalculate);
            this.Controls.Add(this.TextBoxMass);
            this.Controls.Add(this.TextBoxCelsius);
            this.Controls.Add(this.TextBoxArcseconds);
            this.Controls.Add(this.TextBoxRest);
            this.Controls.Add(this.TextBoxObserve);
            this.Controls.Add(this.LabelMass);
            this.Controls.Add(this.LabelHorizon);
            this.Controls.Add(this.LabelCelsius);
            this.Controls.Add(this.LabelKelvin);
            this.Controls.Add(this.LabelAngle);
            this.Controls.Add(this.LabelDistance);
            this.Controls.Add(this.LabelRest);
            this.Controls.Add(this.LabelObserved);
            this.Controls.Add(this.LabelVelocity);
            this.MainMenuStrip = this.MenuStripOptions;
            this.Name = "FormMalinCalculations";
            this.Text = "Malin Calculations";
            this.MenuStripOptions.ResumeLayout(false);
            this.MenuStripOptions.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.NumericMultiplier)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label LabelVelocity;
        private System.Windows.Forms.Label LabelObserved;
        private System.Windows.Forms.Label LabelRest;
        private System.Windows.Forms.Label LabelDistance;
        private System.Windows.Forms.Label LabelAngle;
        private System.Windows.Forms.Label LabelKelvin;
        private System.Windows.Forms.Label LabelCelsius;
        private System.Windows.Forms.Label LabelHorizon;
        private System.Windows.Forms.Label LabelMass;
        private System.Windows.Forms.TextBox TextBoxObserve;
        private System.Windows.Forms.TextBox TextBoxRest;
        private System.Windows.Forms.TextBox TextBoxArcseconds;
        private System.Windows.Forms.TextBox TextBoxCelsius;
        private System.Windows.Forms.TextBox TextBoxMass;
        private System.Windows.Forms.Button ButtonCalculate;
        private System.Windows.Forms.ListView ListViewCalculationResults;
        private System.Windows.Forms.ColumnHeader columnVelocity;
        private System.Windows.Forms.ColumnHeader columnDistance;
        private System.Windows.Forms.ColumnHeader columnKelvin;
        private System.Windows.Forms.ColumnHeader columnHorizon;
        private System.Windows.Forms.StatusStrip StatusStripInfo;
        private System.Windows.Forms.Button ButtonEnglish;
        private System.Windows.Forms.Button ButtonFrench;
        private System.Windows.Forms.Button ButtonGerman;
        private System.Windows.Forms.MenuStrip MenuStripOptions;
        private System.Windows.Forms.Label LabelMultiplier;
        private System.Windows.Forms.NumericUpDown NumericMultiplier;
        private System.Windows.Forms.ToolStripMenuItem MenuItemLanguage;
        private System.Windows.Forms.ToolStripMenuItem MenuItemEnglish;
        private System.Windows.Forms.ToolStripMenuItem MenuItemFrench;
        private System.Windows.Forms.ToolStripMenuItem MenuItemGerman;
        private System.Windows.Forms.ToolStripMenuItem MenuItemStyle;
        private System.Windows.Forms.ToolStripMenuItem MenuItemColor;
        private System.Windows.Forms.ToolStripMenuItem MenuItemForm;
        private System.Windows.Forms.ToolStripMenuItem MenuItemDark;
        private System.Windows.Forms.ToolStripMenuItem MenuItemLight;
        private System.Windows.Forms.Button ButtonDarkLight;
        private System.Windows.Forms.ToolStripMenuItem MenuItemDefault;
        private System.Windows.Forms.Button ButtonDefaultColor;
        private System.Windows.Forms.ToolTip ToolTips;
    }
}

