﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
/* A class file for getters and setters to allow results to be assigned and called during the running of the program.
 */

namespace MalinCalculations
{
    internal class AstroInfo : IComparable<AstroInfo>
    {
        private string Velocity;
        private string Distance;
        private string Kelvin;
        private string Horizon;

        public AstroInfo() { }

        public AstroInfo(string newVelocity, string newDistance, string newKelvin, string newHorizon)
        {
            Velocity = newVelocity;
            Distance = newDistance;
            Kelvin = newKelvin;
            Horizon = newHorizon;
        }
        public void SetVelocity(string newVelocity)
        {
            Velocity = newVelocity;
        }
        public void SetDistance(string newDistance)
        {
            Distance = newDistance;
        }
        public void SetKelvin(string newKelvin)
        {
            Kelvin = newKelvin;
        }
        public void SetHorizon(string newHorizon)
        {
            Horizon = newHorizon;
        }
        public string GetVelocity()
        {
            return Velocity;
        }
        public string GetDistance()
        {
            return Distance;
        }
        public string GetKelvin()
        {
            return Kelvin;
        }
        public string GetHorizon()
        {
            return Horizon;
        }
        public int CompareTo(AstroInfo other)
        {
            return Velocity.CompareTo(other.GetVelocity());
        }
    }
}
