﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
/* Christopher Prickett - 30053736. 3/04/2023
 * Complex Data Structure, Assessment 2.
 * Creating a client program that will perform calculations based on user input and use a dll to perform the calculations.
 * Can also change between English, German and French. The form can also have the color changed based on button press or color wheel.
 */

namespace MalinCalculations
{
    public partial class FormMalinCalculations : Form
    {
        public FormMalinCalculations()
        {
            InitializeComponent();           
        }
        /// <summary>
        /// A list of type <AstroInfo> that will get and set values for calculations.
        /// </summary>
        List<AstroInfo> astroInfo = new List<AstroInfo>();
        /// <summary>
        /// A boolean to aid with the changing of the color scheme.
        /// </summary>
        bool darkOn = false;
        #region Color Changes
        /// <summary>
        /// Menu item click event to open the color window to select color for the form.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void MenuItemColor_Click(object sender, EventArgs e)
        {
            ColorDialog colorDialog = new ColorDialog();
            if (colorDialog.ShowDialog() == DialogResult.OK)
            {
                BackColor = colorDialog.Color;
                byte r = (byte)(255 - BackColor.R);
                byte g = (byte)(255 - BackColor.G);
                byte b = (byte)(255 - BackColor.B);
                ForeColor = Color.FromArgb(r, g, b);
                foreach (var textBox in Controls.OfType<TextBox>())
                {
                    textBox.ForeColor = Color.FromArgb(r, g, b);
                }
            }
        }
        /// <summary>
        /// A button method to change the form between "dark" and "light" mode.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ButtonDarkLight_MouseClick(object sender, MouseEventArgs e)
        {
            if (darkOn)
            {
                BackgroundImage = null;
                BackColor = Color.Khaki;
                ForeColor = Color.SteelBlue;
                foreach (var button in Controls.OfType<Button>())
                {
                    button.BackColor = Color.PapayaWhip;
                    button.FlatStyle = FlatStyle.Flat;
                    button.FlatAppearance.BorderColor = Color.OrangeRed;
                }
                foreach (var label in Controls.OfType<Label>())
                {
                    label.ForeColor = Color.SeaGreen;
                }
                foreach (var textBox in Controls.OfType<TextBox>())
                {
                    textBox.ForeColor = Color.DarkOrchid;
                }
                darkOn = false;
            }
            else
            {
                BackgroundImage = null;
                BackColor = Color.DarkSlateBlue;
                ForeColor = Color.Black;
                foreach (var button in Controls.OfType<Button>())
                {
                    button.BackColor = Color.SteelBlue;
                    button.FlatStyle = FlatStyle.Flat;
                    button.FlatAppearance.BorderColor = Color.SlateBlue;

                }
                foreach (var label in Controls.OfType<Label>())
                {
                    label.ForeColor = Color.LemonChiffon;
                }
                foreach (var textBox in Controls.OfType<TextBox>())
                {
                    textBox.ForeColor = Color.SeaGreen;
                }
                darkOn = true;
            }
        }
        /// <summary>
        /// A menu item click event to change the form to "default" color scheme.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void MenuItemDefault_Click(object sender, EventArgs e)
        {
            if (darkOn)
            {
                BackgroundImage = null;
                BackColor = Color.Gainsboro;
                ForeColor = Color.Black;
                foreach (var button in Controls.OfType<Button>())
                {
                    button.BackColor = Color.WhiteSmoke;
                    button.FlatStyle = FlatStyle.Flat;
                    button.FlatAppearance.BorderColor = Color.Black;
                }
                foreach (var label in Controls.OfType<Label>())
                {
                    label.ForeColor = Color.Black;
                }
                foreach (var textBox in Controls.OfType<TextBox>())
                {
                    textBox.ForeColor = Color.Black;
                }
                darkOn = false;
            }
            else
            {
                BackgroundImage = null;
                BackColor = Color.Gainsboro;
                ForeColor = Color.Black;
                foreach (var button in Controls.OfType<Button>())
                {
                    button.BackColor = Color.WhiteSmoke;
                    button.FlatStyle = FlatStyle.Flat;
                    button.FlatAppearance.BorderColor = Color.Black;

                }
                foreach (var label in Controls.OfType<Label>())
                {
                    label.ForeColor = Color.Black;
                }
                foreach (var textBox in Controls.OfType<TextBox>())
                {
                    textBox.ForeColor = Color.Black;
                }
            }
        }
        /// <summary>
        /// A menu item click event to change the form to "dark" mode.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void MenuItemDark_Click(object sender, EventArgs e)
        {
            BackgroundImage = null;
            BackColor = Color.DarkSlateBlue;
            ForeColor = Color.Black;
            foreach (var button in Controls.OfType<Button>())
            {
                button.BackColor = Color.SteelBlue;
                button.FlatStyle = FlatStyle.Flat;
                button.FlatAppearance.BorderColor = Color.SlateBlue;

            }
            foreach (var label in Controls.OfType<Label>())
            {
                label.ForeColor = Color.LemonChiffon;
            }
            foreach (var textBox in Controls.OfType<TextBox>())
            {
                textBox.ForeColor = Color.SeaGreen;
            }
            darkOn = true;
        }
        /// <summary>
        /// A menu item click event to change the form to "light" mode.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void MenuItemLight_Click(object sender, EventArgs e)
        {
            BackgroundImage = null;
            BackColor = Color.Khaki;
            ForeColor = Color.SteelBlue;
            foreach (var button in Controls.OfType<Button>())
            {
                button.BackColor = Color.PapayaWhip;
                button.FlatStyle = FlatStyle.Flat;
                button.FlatAppearance.BorderColor = Color.OrangeRed;
            }
            foreach (var label in Controls.OfType<Label>())
            {
                label.ForeColor = Color.SeaGreen;
            }
            foreach (var textBox in Controls.OfType<TextBox>())
            {
                textBox.ForeColor = Color.DarkOrchid;
            }
            darkOn = false;
        }
        /// <summary>
        /// A button method to change the for to "default" color scheme.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ButtonDefaultColor_MouseClick(object sender, MouseEventArgs e)
        {
            if (darkOn)
            {
                BackgroundImage = null;
                BackColor = Color.Gainsboro;
                ForeColor = Color.Black;
                foreach (var button in Controls.OfType<Button>())
                {
                    button.BackColor = Color.WhiteSmoke;
                    button.FlatStyle = FlatStyle.Flat;
                    button.FlatAppearance.BorderColor = Color.Black;
                }
                foreach (var label in Controls.OfType<Label>())
                {
                    label.ForeColor = Color.Black;
                }
                foreach (var textBox in Controls.OfType<TextBox>())
                {
                    textBox.ForeColor = Color.Black;
                }
                darkOn = false;
            }
            else
            {
                BackgroundImage = null;
                BackColor = Color.Gainsboro;
                ForeColor = Color.Black;
                foreach (var button in Controls.OfType<Button>())
                {
                    button.BackColor = Color.WhiteSmoke;
                    button.FlatStyle = FlatStyle.Flat;
                    button.FlatAppearance.BorderColor = Color.Black;

                }
                foreach (var label in Controls.OfType<Label>())
                {
                    label.ForeColor = Color.Black;
                }
                foreach (var textBox in Controls.OfType<TextBox>())
                {
                    textBox.ForeColor = Color.Black;
                }
            }
        }
        #endregion Color Changes
        #region Misc
        /// <summary>
        /// Status strip information displayed depending on switch/case message received from program.
        /// </summary>
        /// <param name="msg">Error message to be displayed based on error that has occured.</param>
        private void Info(int msg)
        {
            StatusStripInfo.Items.Clear();
            switch (msg)
            {
                case 1:
                    if (LabelVelocity.Text == Properties.English.LabelVelocity)
                    {
                        StatusStripInfo.Items.Add("Information missing, check all calculations have values.");
                    }
                    else if (LabelVelocity.Text == Properties.French.LabelVelocity)
                    {
                        StatusStripInfo.Items.Add("Informations manquantes, vérifiez que tous les calculs ont des valeurs.");
                    }
                    else if (LabelVelocity.Text == Properties.German.LabelVelocity)
                    {
                        StatusStripInfo.Items.Add("Informationen fehlen, überprüfen Sie, ob alle Berechnungen Werte haben.");
                    }
                    break;
                case 2:
                    if (LabelVelocity.Text == Properties.English.LabelVelocity)
                    {
                        StatusStripInfo.Items.Add("Error during calculations, please try again.");
                    }
                    else if (LabelVelocity.Text == Properties.French.LabelVelocity)
                    {
                        StatusStripInfo.Items.Add("Erreur lors des calculs, veuillez réessayer.");
                    }
                    else if (LabelVelocity.Text == Properties.German.LabelVelocity)
                    {
                        StatusStripInfo.Items.Add("Fehler bei Berechnungen, bitte versuchen Sie es erneut.");
                    }
                    break;
            }
        }
        /// <summary>
        /// Method to clear all text boxes, used after calculation has been performed.
        /// </summary>
        private void ClearText()
        {
            TextBoxObserve.Clear();
            TextBoxRest.Clear();
            TextBoxArcseconds.Clear();
            TextBoxCelsius.Clear();
            TextBoxMass.Clear();
            NumericMultiplier.Value = 0;
            StatusStripInfo.Items.Clear();
            TextBoxObserve.Focus();
        }
        /// <summary>
        /// Display method to display each calculation in the correct row. Used after calculation is performed.
        /// </summary>
        private void Display()
        {
            ListViewCalculationResults.Items.Clear();
            foreach (var AstroInfo in astroInfo)
            {
                ListViewItem item = new ListViewItem(AstroInfo.GetVelocity());
                item.SubItems.Add(AstroInfo.GetDistance());
                item.SubItems.Add(AstroInfo.GetKelvin());
                item.SubItems.Add(AstroInfo.GetHorizon());
                ListViewCalculationResults.Items.Add(item);
            }
        }
        #endregion Misc
        #region Calculate
        /// <summary>
        /// A button method that will take the input from the user in text boxes, use the server connection to perform
        /// the calculations, then return the results. The results will be added to the list and displayed in the list view.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ButtonCalculate_MouseClick(object sender, MouseEventArgs e)
        {
            try
            {
                AstroInfo astro = new AstroInfo();
                string address = "net.pipe://localhost/astronumbers";
                NetNamedPipeBinding binding = new NetNamedPipeBinding(NetNamedPipeSecurityMode.None);
                EndpointAddress ep = new EndpointAddress(address);
                IAstroContract channel = ChannelFactory<IAstroContract>.CreateChannel(binding, ep);

                if (!string.IsNullOrEmpty(TextBoxObserve.Text) &&
                    !string.IsNullOrEmpty(TextBoxRest.Text))
                {
                    double observed = double.Parse(TextBoxObserve.Text);
                    double rest = double.Parse(TextBoxRest.Text);
                    double velocity = Math.Round(channel.StarVelocity(observed, rest), 6);
                    astro.SetVelocity(velocity.ToString() + " m/s");
                }
                if (!string.IsNullOrEmpty(TextBoxArcseconds.Text))
                {
                    double arc = double.Parse(TextBoxArcseconds.Text);
                    double distance = channel.StarDistance(arc);
                    astro.SetDistance(distance.ToString("E3") + " parsecs");
                }
                if (!string.IsNullOrEmpty(TextBoxCelsius.Text))
                {
                    double celsius = double.Parse(TextBoxCelsius.Text);
                    double kelvin = channel.DegreesKelvin(celsius);
                    astro.SetKelvin(kelvin.ToString() + " K");
                }
                if (!string.IsNullOrEmpty(TextBoxMass.Text))
                {
                    double mass = double.Parse(TextBoxMass.Text);
                    double massPower = double.Parse(NumericMultiplier.Value.ToString());
                    double result = mass * Math.Pow(10, massPower);
                    double horizon = channel.EventHorizon(result);
                    astro.SetHorizon(horizon.ToString("E3") + " m");
                }
                astroInfo.Add(astro);
                StatusStripInfo.Items.Clear();

                Display();
                ClearText();
            }
            catch
            {
                Info(2);
            }
        }
        #endregion Calculate
        #region Language
        /// <summary>
        /// A method for changing form language to English using the English resource file.
        /// </summary>
        private void English()
        {
            LabelVelocity.Text = Properties.English.LabelVelocity;
            LabelObserved.Text = Properties.English.LabelObserved;
            LabelRest.Text = Properties.English.LabelRest;
            LabelKelvin.Text = Properties.English.LabelKelvin;
            LabelCelsius.Text = Properties.English.LabelCelsius;
            LabelDistance.Text = Properties.English.LabelDistance;
            LabelAngle.Text = Properties.English.LabelAngle;
            LabelHorizon.Text = Properties.English.LabelHorizon;
            LabelMass.Text = Properties.English.LabelMass;
            LabelMultiplier.Text = Properties.English.LabelMultiplier;
            ButtonCalculate.Text = Properties.English.ButtonCalculate;
            ButtonDarkLight.Text = Properties.English.ButtonDarkLight;
            ButtonDefaultColor.Text = Properties.English.ButtonDefaultColor;
            ButtonEnglish.Text = Properties.English.ButtonEnglish;
            ButtonFrench.Text = Properties.English.ButtonFrench;
            ButtonGerman.Text = Properties.English.ButtonGerman;
            MenuItemLanguage.Text = Properties.English.MenuItemLanguage;
            MenuItemEnglish.Text = Properties.English.MenuItemEnglish;
            MenuItemFrench.Text = Properties.English.MenuItemFrench;
            MenuItemGerman.Text = Properties.English.MenuItemGerman;
            MenuItemStyle.Text = Properties.English.MenuItemStyle;
            MenuItemForm.Text = Properties.English.MenuItemForm;
            MenuItemColor.Text = Properties.English.MenuItemColor;
            MenuItemDark.Text = Properties.English.MenuItemDark;
            MenuItemLight.Text = Properties.English.MenuItemLight;
            MenuItemDefault.Text = Properties.English.MenuItemDefault;
            columnDistance.Text = Properties.English.columnDistance;
            columnHorizon.Text = Properties.English.columnHorizon;
            columnKelvin.Text = Properties.English.columnKelvin;
            columnVelocity.Text = Properties.English.columnVelocity;
            ToolTips.SetToolTip(TextBoxObserve, "Enter Observed Wavelength (nm).");
            ToolTips.SetToolTip(TextBoxRest, "Enter Rest Wavelength (nm).");
            ToolTips.SetToolTip(TextBoxArcseconds, "Enter Parallax Angle (arcs).");
            ToolTips.SetToolTip(TextBoxCelsius, "Enter Temperature in Celsius.");
            ToolTips.SetToolTip(TextBoxMass, "Enter Black Hole Mass (kg).");
            ToolTips.SetToolTip(ButtonEnglish, "Change Language to English.");
            MenuItemEnglish.ToolTipText = "Change Language to English.";
            ToolTips.SetToolTip(ButtonFrench, "Change Language to French.");
            MenuItemFrench.ToolTipText = "Change Language to French.";
            ToolTips.SetToolTip(ButtonGerman, "Change Language to German.");
            MenuItemGerman.ToolTipText = "Change Language to German.";
            ToolTips.SetToolTip(ButtonCalculate, "Calculate all information.");
            ToolTips.SetToolTip(ButtonDarkLight, "Change to dark/light mode.");
            ToolTips.SetToolTip(ButtonDefaultColor, "Change to Default Colors.");
            ToolTips.SetToolTip(NumericMultiplier, "Input Multiplier.");
            MenuItemColor.ToolTipText = "Customise Color Change.";
            MenuItemDark.ToolTipText = "Change to dark mode.";
            MenuItemLight.ToolTipText = "Change to light mode.";
            MenuItemDefault.ToolTipText = "Change to default colors.";
        }
        /// <summary>
        /// Button method to change the form language to English, calls the English method.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ButtonEnglish_MouseClick(object sender, MouseEventArgs e)
        {
            English();
        }
        /// <summary>
        /// Menu item click event to change the form language to English, calls the English method.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void MenuItemEnglish_Click(object sender, EventArgs e)
        {
            English();
        }
        /// <summary>
        /// A method for changing the form language to French using the French resource file.
        /// </summary>
        private void French()
        {
            LabelVelocity.Text = Properties.French.LabelVelocity;
            LabelObserved.Text = Properties.French.LabelObserved;
            LabelRest.Text = Properties.French.LabelRest;
            LabelKelvin.Text = Properties.French.LabelKelvin;
            LabelCelsius.Text = Properties.French.LabelCelsius;
            LabelDistance.Text = Properties.French.LabelDistance;
            LabelAngle.Text = Properties.French.LabelAngle;
            LabelHorizon.Text = Properties.French.LabelHorizon;
            LabelMass.Text = Properties.French.LabelMass;
            LabelMultiplier.Text = Properties.French.LabelMultiplier;
            ButtonCalculate.Text = Properties.French.ButtonCalculate;
            ButtonDarkLight.Text = Properties.French.ButtonDarkLight;
            ButtonDefaultColor.Text = Properties.French.ButtonDefaultColor;
            ButtonEnglish.Text = Properties.French.ButtonEnglish;
            ButtonFrench.Text = Properties.French.ButtonFrench;
            ButtonGerman.Text = Properties.French.ButtonGerman;
            MenuItemLanguage.Text = Properties.French.MenuItemLanguage;
            MenuItemEnglish.Text = Properties.French.MenuItemEnglish;
            MenuItemFrench.Text = Properties.French.MenuItemFrench;
            MenuItemGerman.Text = Properties.French.MenuItemGerman;
            MenuItemStyle.Text = Properties.French.MenuItemStyle;
            MenuItemForm.Text = Properties.French.MenuItemForm;
            MenuItemColor.Text = Properties.French.MenuItemColor;
            MenuItemDark.Text = Properties.French.MenuItemDark;
            MenuItemLight.Text = Properties.French.MenuItemLight;
            MenuItemDefault.Text = Properties.French.MenuItemDefault;
            columnDistance.Text = Properties.French.columnDistance;
            columnHorizon.Text = Properties.French.columnHorizon;
            columnKelvin.Text = Properties.French.columnKelvin;
            columnVelocity.Text = Properties.French.columnVelocity;
            ToolTips.SetToolTip(TextBoxObserve, "Entrer la longueur d'onde observée (nm).");
            ToolTips.SetToolTip(TextBoxRest, "Entrez la longueur d'onde de repos (nm).");
            ToolTips.SetToolTip(TextBoxArcseconds, "Entrer l'angle de parallaxe (arcs).");
            ToolTips.SetToolTip(TextBoxCelsius, "Entrez la température en degrés Celsius.");
            ToolTips.SetToolTip(TextBoxMass, "Entrez dans la masse du trou noir (kg).");
            ToolTips.SetToolTip(ButtonEnglish, "Changer la langue en anglais.");
            MenuItemEnglish.ToolTipText = "Changer la langue en anglais.";
            ToolTips.SetToolTip(ButtonFrench, "Changer la langue en français.");
            MenuItemFrench.ToolTipText = "Changer la langue en français.";
            ToolTips.SetToolTip(ButtonGerman, "Changer la langue en allemand.");
            MenuItemGerman.ToolTipText = "Changer la langue en allemand.";
            ToolTips.SetToolTip(ButtonCalculate, "Calculer toutes les informations.");
            ToolTips.SetToolTip(ButtonDarkLight, "Passer en mode sombre/clair.");
            ToolTips.SetToolTip(ButtonDefaultColor, "Passer aux couleurs par défaut.");
            ToolTips.SetToolTip(NumericMultiplier, "Multiplicateur d'entrée.");
            MenuItemColor.ToolTipText = "Personnaliser le changement de couleur.";
            MenuItemDark.ToolTipText = "Passer en mode sombre.";
            MenuItemLight.ToolTipText = "Passer en mode lumière.";
            MenuItemDefault.ToolTipText = "Passer aux couleurs par défaut.";
        }
        /// <summary>
        /// A button method to change the form language to French, calls the French method.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ButtonFrench_MouseClick(object sender, MouseEventArgs e)
        {
            French();
        }
        /// <summary>
        /// A menu item click event to change the form language to French, calls the French method.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void MenuItemFrench_Click(object sender, EventArgs e)
        {
            French();
        }
        /// <summary>
        /// A method for changing the form language to German using the German resource file.
        /// </summary>
        private void German()
        {
            LabelVelocity.Text = Properties.German.LabelVelocity;
            LabelObserved.Text = Properties.German.LabelObserved;
            LabelRest.Text = Properties.German.LabelRest;
            LabelKelvin.Text = Properties.German.LabelKelvin;
            LabelCelsius.Text = Properties.German.LabelCelsius;
            LabelDistance.Text = Properties.German.LabelDistance;
            LabelAngle.Text = Properties.German.LabelAngle;
            LabelHorizon.Text = Properties.German.LabelHorizon;
            LabelMass.Text = Properties.German.LabelMass;
            LabelMultiplier.Text = Properties.German.LabelMultiplier;
            ButtonCalculate.Text = Properties.German.ButtonCalculate;
            ButtonDarkLight.Text = Properties.German.ButtonDarkLight;
            ButtonDefaultColor.Text = Properties.German.ButtonDefaultColor;
            ButtonEnglish.Text = Properties.German.ButtonEnglish;
            ButtonFrench.Text = Properties.German.ButtonFrench;
            ButtonGerman.Text = Properties.German.ButtonGerman;
            MenuItemLanguage.Text = Properties.German.MenuItemLanguage;
            MenuItemEnglish.Text = Properties.German.MenuItemEnglish;
            MenuItemFrench.Text = Properties.German.MenuItemFrench;
            MenuItemGerman.Text = Properties.German.MenuItemGerman;
            MenuItemStyle.Text = Properties.German.MenuItemStyle;
            MenuItemForm.Text = Properties.German.MenuItemForm;
            MenuItemColor.Text = Properties.German.MenuItemColor;
            MenuItemDark.Text = Properties.German.MenuItemDark;
            MenuItemLight.Text = Properties.German.MenuItemLight;
            MenuItemDefault.Text = Properties.German.MenuItemDefault;
            columnDistance.Text = Properties.German.columnDistance;
            columnHorizon.Text = Properties.German.columnHorizon;
            columnKelvin.Text = Properties.German.columnKelvin;
            columnVelocity.Text = Properties.German.columnVelocity;
            ToolTips.SetToolTip(TextBoxObserve, "Beobachtete Wellenlänge eingeben (nm).");
            ToolTips.SetToolTip(TextBoxRest, "Geben Sie die Ruhewellenlänge ein (nm).");
            ToolTips.SetToolTip(TextBoxArcseconds, "Geben Sie den Parallaxenwinkel ein (arcs).");
            ToolTips.SetToolTip(TextBoxCelsius, "Geben Sie die Temperatur in Celsius ein.");
            ToolTips.SetToolTip(TextBoxMass, "Geben Sie die Masse des Schwarzen Lochs ein (kg).");
            ToolTips.SetToolTip(ButtonEnglish, "Sprache auf Englisch ändern.");
            MenuItemEnglish.ToolTipText = "Sprache auf Englisch ändern.";
            ToolTips.SetToolTip(ButtonFrench, "Sprache auf Französisch ändern.");
            MenuItemFrench.ToolTipText = "Sprache auf Französisch ändern.";
            ToolTips.SetToolTip(ButtonGerman, "Sprache auf Deutsch umstellen.");
            MenuItemGerman.ToolTipText = "Sprache auf Deutsch umstellen.";
            ToolTips.SetToolTip(ButtonCalculate, "Berechnen Sie alle Informationen.");
            ToolTips.SetToolTip(ButtonDarkLight, "Wechseln Sie in den Dunkel-/Hell-Modus.");
            ToolTips.SetToolTip(ButtonDefaultColor, "Wechseln Sie zu den Standardfarben.");
            ToolTips.SetToolTip(NumericMultiplier, "Eingangsmultiplikator.");
            MenuItemColor.ToolTipText = "Farbwechsel anpassen.";
            MenuItemDark.ToolTipText = "Wechseln Sie in den dunklen Modus.";
            MenuItemLight.ToolTipText = "Wechseln Sie in den Lichtmodus.";
            MenuItemDefault.ToolTipText = "Wechseln Sie zu den Standardfarben.";
        }
        /// <summary>
        /// A button method to change the form language to German, calls the German method.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ButtonGerman_MouseClick(object sender, MouseEventArgs e)
        {
            German();
        }
        /// <summary>
        /// A menu item click event to change the form language to German, calls the German method.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void MenuItemGerman_Click(object sender, EventArgs e)
        {
            German();
        }
        #endregion Language
    }
}
